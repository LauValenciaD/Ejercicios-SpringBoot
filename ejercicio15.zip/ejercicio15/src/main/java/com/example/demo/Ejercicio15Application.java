package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio15Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio15Application.class, args);
	}

}
