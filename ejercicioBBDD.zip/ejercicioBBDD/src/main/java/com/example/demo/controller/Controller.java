package com.example.demo.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Cliente;
import com.example.demo.service.ClienteServicio;

@RestController
@RequestMapping("/clientes")
public class Controller {

	@Autowired // conectar con el autowired
	private ClienteServicio servicio; // crear una variable de la clase ClienteServicio

	@GetMapping // Mostrar todos las Clientes
	public ResponseEntity<List> getClientes() {
		List<Cliente> lista = servicio.getClientes(); // llamamos al servicio
		return ResponseEntity.ok(lista);
	}

	@GetMapping("/{id}") // consultar una Cliente por su titulo
	public ResponseEntity<Cliente> getTitulo(@PathVariable Integer id) {
		Cliente cliente = servicio.getCliente(id);
		if (cliente == null) {
			return ResponseEntity.notFound().build();
		} else
			return ResponseEntity.ok(cliente);

	}

	@PostMapping // añadir una nueva Cliente
	public ResponseEntity<Cliente> postCliente(@RequestBody Cliente cliente) { // en el postman escribir en el body raw
																				// // los // datos del cliente como en
																				// el JSON
		servicio.insertaCliente(cliente);
		return ResponseEntity.noContent().build();
	}
	/*
	 * 
	 * 
	 * 
	 * 
	 * @PutMapping("/{id}") // modificacion total public ResponseEntity<Cliente>
	 * putAlumno(@RequestBody Cliente film, @PathVariable int id) // busca a un
	 * cliente // // actualiza { for (Cliente Cliente : listaClientes) { // hacer un
	 * for each para ver todos los datos del cliente if (Cliente.getId() == id) //
	 * si coincide devuelve el cliente { Cliente.setTitulo(film.getTitulo());
	 * Cliente.setDirector(film.getDirector());
	 * Cliente.setFechaLanzamiento(film.getFechaLanzamiento());
	 * Cliente.setDuracion(film.getDuracion());
	 * Cliente.setActores(film.getActores());
	 * 
	 * return ResponseEntity.noContent().build(); } } return
	 * ResponseEntity.notFound().build(); }
	 * 
	 * @PatchMapping public ResponseEntity<Cliente> patchCliente(@RequestBody
	 * Cliente film) { // modificacion total for (Cliente Cliente : listaClientes) {
	 * if (Cliente.getId() == film.getId()) {
	 * 
	 * if (film.getTitulo() != null) {
	 * 
	 * Cliente.setTitulo(film.getTitulo()); } if (film.getDirector() != null) {
	 * 
	 * Cliente.setDirector(film.getDirector()); } if (film.getFechaLanzamiento() !=
	 * null) {
	 * 
	 * Cliente.setFechaLanzamiento(film.getFechaLanzamiento()); } if
	 * (film.getDuracion() != 0) {
	 * 
	 * Cliente.setDuracion(film.getDuracion()); } if (film.getActores() != null) {
	 * Cliente.setActores(film.getActores()); }
	 * 
	 * return ResponseEntity.noContent().build(); } } return
	 * ResponseEntity.notFound().build(); }
	 * 
	 * @DeleteMapping("/{id}") // borrar Cliente por su id public
	 * ResponseEntity<Cliente> deleteAlumno(@PathVariable int id) {
	 * Iterator<Cliente> iterator = listaClientes.iterator(); // para borrar NO usar
	 * for each porque puede dar error while (iterator.hasNext()) { Cliente Cliente
	 * = iterator.next(); if (Cliente.getId() == id) { iterator.remove(); return
	 * ResponseEntity.noContent().build(); } } return
	 * ResponseEntity.notFound().build(); }
	 */
}
