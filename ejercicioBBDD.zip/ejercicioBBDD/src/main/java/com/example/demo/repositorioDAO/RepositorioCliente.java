package com.example.demo.repositorioDAO;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.model.Cliente;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

@Repository
public class RepositorioCliente {

	@PersistenceContext
	private EntityManager entityManager; //creamos el entityManager
	
	public List<Cliente> getClientes(){
		Query query = (Query) entityManager.createQuery("select c from Cliente c", Cliente.class);
		List<Cliente> lista = query.getResultList();
		return lista;
	}
	
	public Cliente insertaCliente (Cliente cliente) {
		//es necesario @transaccional en el servicio
		entityManager.persist(cliente);
		System.out.println(cliente); //para ver los datos en consola
		return cliente;
	}

	public Cliente getCliente(Integer id) {
		Cliente cliente = entityManager.find(Cliente.class, id);
		return cliente;
	}
	
}
